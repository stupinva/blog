This software upgrade package includes the following Cisco ATA 186/188 files.

Filename                 Description
=======================  =======================================================
ATA030201SIP050616A.zup  Cisco ATA 186/188 SIP upgrade image
atapost.pl               Perl script to change parameter/value without browser
atapost.txt              Instructions for using atapost.pl
audiocfg.htm             Sample "Audio Parameters" page with default settings
bitaid.exe               Tool to display and modify bitmap values (Windows)
bitaid.txt               Instructions for using bitaid program
cfgfmt.exe               Convert SIP profile from text to binary (Windows)
cfgfmt.linux             Convert SIP profile from text to binary (Linux)
cfgfmt.sun               Convert SIP profile from text to binary (Solaris)
cfgfmt.txt               Instructions for using cfgfmt program
DebugCfg.htm             Sample "Debug Parameters" page with default settings
NetCfg.htm               Sample "Network Parameters" page with default settings
prserv.exe               Capture Cisco ATA log (Windows)
prserv.linux             Capture Cisco ATA log (Linux)
prserv.sun               Capture Cisco ATA log (Solaris)
prserv.txt               Instructions for using prserv program
ptag.dat                 Parameter tag data for use with cfgfmt program 
readme.txt               This file
sata186us.exe            Server for manual image upgrade (Windows)
sata186us.linux          Server for manual image upgrade (Linux)
sata186us.sun            Server for manual image upgrade (Solaris)
sata186us.txt            Instructions for using sata186us 
ServiceCfg.htm           Sample "Service Parameters" page with default settings
sip_example.txt          Example Cisco ATA 186/188 SIP profile
SIPCfg.htm               Sample "SIP Parameters" page with default settings
ToneCfg.htm              Sample "Tone Parameters" page with default settings
transition.zup           Transition image for upgrading from 1.34 or earlier S/W
zupinfo.exe              Image identification tool (Windows)
zupinfo.txt              Instructions using zupinfo program
=======================  =======================================================

Please refer to the Cisco ATA 186/188 Administrator Guide (SIP) for more
information on the usage of some of these programs.  

The Cisco ATA 186/188 Administrator Guide (SIP) and release notes are available
at the following URLs:

http://www.cisco.com/en/US/products/hw/gatecont/ps514/prod_maintenance_guides_list.html  
http://www.cisco.com/en/US/products/hw/gatecont/ps514/prod_release_notes_list.html


--------------------------------------------------------------------------------
                 UPGRADING FROM ATA 186 VERSION 1.34 OR EARLIER                
--------------------------------------------------------------------------------

Users of Cisco ATA 186 version 1.34 or earlier software versions may not 
upgrade directly to version 2.10 or later software versions.  

To upgrade from version 1.34 or earlier software versions, the Cisco ATA 186
must first be upgraded to a transition software image (trasition.zup) and
then upgraded to version 2.10 or later software versions.

